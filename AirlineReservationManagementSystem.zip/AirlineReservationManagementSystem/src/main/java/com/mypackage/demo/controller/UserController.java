package com.mypackage.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.mypackage.demo.model.User;
import com.mypackage.demo.service.UserService;

@RestController
@RequestMapping("api/user")
public class UserController {
	@Autowired
	private UserService userService;
	
	@PostMapping
	public ResponseEntity<User> addUser(@RequestBody User user){
		return new ResponseEntity<User> (userService.addUser(user),HttpStatus.CREATED);
	}
	@GetMapping
	public List<User> findAllStudent(){
		return userService.getAllUsers();
	}
	@GetMapping("/{userId}")
	public ResponseEntity<User> getUserById(@PathVariable("userId") int userId){
		return new ResponseEntity<User> (userService.getUserById(userId),HttpStatus.OK);
	}
	@DeleteMapping("/{userId}")
	public ResponseEntity<String> removeUserById(@PathVariable("userId") int userId){
		userService.removeUserById(userId);
		return new ResponseEntity<String>("Deleted SuccessFully",HttpStatus.OK);
	}
	@DeleteMapping("/getUserafterremoving/{userId}")
	public List<User> removeUserById1(@PathVariable("userId") int userId){
		userService.removeUserById(userId);
		return userService.getAllUsers();
	}
	@PutMapping("/{userId}")
	public ResponseEntity<User> updateUserById(@PathVariable("userId") int userId,@RequestBody User user){
		return new ResponseEntity<User> (userService.updateUserById(userId, user),HttpStatus.OK);
	}

}
