package com.mypackage.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.mypackage.demo.model.User;

public interface UserService {
	public User addUser(User user);
	public List<User> getAllUsers();
	public User getUserById(int userId);
	public void removeUserById(int userId);
	public User updateUserById(int userId,User user);
}
