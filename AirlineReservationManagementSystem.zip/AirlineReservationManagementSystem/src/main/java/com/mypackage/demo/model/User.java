package com.mypackage.demo.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="UserTable")
public class User {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="UserId")
	private int userId;
	@Column(name="FisrtName",nullable=false)
	private String userFirstName;
	@Column(name="LastName",nullable=false)
	private String userLastName;
	@Column(name="EmailAddress",nullable=false,unique=true)
	private String userEmail;
	@Column(name="MobileNo",nullable=false,unique=true)
	private String userMobileNo;
	@Column(name="Password",nullable=false,unique=true)
	private String userPassword;
	@Column(name="PassportNo",nullable=false,unique=true)
	private String userPassportNo;
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	public String getUserFirstName() {
		return userFirstName;
	}
	public void setUserFirstName(String userFirstName) {
		this.userFirstName = userFirstName;
	}
	public String getUserLastName() {
		return userLastName;
	}
	public void setUserLastName(String userLastName) {
		this.userLastName = userLastName;
	}
	public String getUserEmail() {
		return userEmail;
	}
	public void setUserEmail(String userEmail) {
		this.userEmail = userEmail;
	}
	public String getUserMobileNo() {
		return userMobileNo;
	}
	public void setUserMobileNo(String userMobileNo) {
		this.userMobileNo = userMobileNo;
	}
	public String getUserPassword() {
		return userPassword;
	}
	public void setUserPassword(String userPassword) {
		this.userPassword = userPassword;
	}
	public String getUserPassportNo() {
		return userPassportNo;
	}
	public void setUserPassportNo(String userPassportNo) {
		this.userPassportNo = userPassportNo;
	}
	
}
