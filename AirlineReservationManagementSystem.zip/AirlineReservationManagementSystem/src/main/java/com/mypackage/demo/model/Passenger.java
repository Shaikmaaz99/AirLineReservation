package com.mypackage.demo.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="Passenger_Table")
public class Passenger {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="Passenger_Id")
	private int pId;
	@Column(name="FirstName")
	private String pFirstName;
	@Column(name="LastName")
	private String pLastName;
	@Column(name="Email")
	private String pEmail;
	@Column(name="MobileNo")
	private String pMobileNo;
	@Column(name="Password")
	private String pPassword;
	@Column(name="PassportNo")
	private String pPassportNo;
	public int getpId() {
		return pId;
	}
	public void setpId(int pId) {
		this.pId = pId;
	}
	public String getpFirstName() {
		return pFirstName;
	}
	public void setpFirstName(String pFirstName) {
		this.pFirstName = pFirstName;
	}
	public String getpLastName() {
		return pLastName;
	}
	public void setpLastName(String pLastName) {
		this.pLastName = pLastName;
	}
	public String getpEmail() {
		return pEmail;
	}
	public void setpEmail(String pEmail) {
		this.pEmail = pEmail;
	}
	public String getpMobileNo() {
		return pMobileNo;
	}
	public void setpMobileNo(String pMobileNo) {
		this.pMobileNo = pMobileNo;
	}
	public String getpPassword() {
		return pPassword;
	}
	public void setpPassword(String pPassword) {
		this.pPassword = pPassword;
	}
	public String getpPassportNo() {
		return pPassportNo;
	}
	public void setpPassportNo(String pPassportNo) {
		this.pPassportNo = pPassportNo;
	}
	
}
