package com.mypackage.demo.serviceimpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mypackage.demo.model.Passenger;
import com.mypackage.demo.repository.PassengerRepository;
import com.mypackage.demo.service.PassengerService;

@Service
public class PassengerServiceImpl implements PassengerService{
	@Autowired
	private PassengerRepository passengerRepository;

	@Override
	public Passenger addPassenger(Passenger passenger) {
		// TODO Auto-generated method stub
		return passengerRepository.save(passenger);
	}

	@Override
	public List<Passenger> getAllPassenger() {
		// TODO Auto-generated method stub
		return passengerRepository.findAll();
	}

	@Override
	public Passenger getPassengerById(int pId) {
		// TODO Auto-generated method stub
		return passengerRepository.findById(pId).get();
	}

	@Override
	public void removePassengerById(int pId) {
		// TODO Auto-generated method stub
		Passenger passenger=getPassengerById(pId);
		passengerRepository.deleteById(pId);
		
	}

	@Override
	public Passenger updatePassengerById(int pId, Passenger newpassengerDetails) {
		// TODO Auto-generated method stub
		Passenger existingPassengerInfo=getPassengerById(pId);
		existingPassengerInfo.setpFirstName(newpassengerDetails.getpFirstName());
		existingPassengerInfo.setpLastName(newpassengerDetails.getpLastName());
		existingPassengerInfo.setpEmail(newpassengerDetails.getpEmail());
		existingPassengerInfo.setpMobileNo(newpassengerDetails.getpMobileNo());
		existingPassengerInfo.setpPassword(newpassengerDetails.getpPassword());
		existingPassengerInfo.setpPassportNo(newpassengerDetails.getpPassportNo());
		return passengerRepository.save(newpassengerDetails);
	}
}
