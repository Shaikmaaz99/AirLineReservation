package com.mypackage.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.mypackage.demo.model.Passenger;
import com.mypackage.demo.service.PassengerService;

@RestController
@RequestMapping("/passenger")
public class PassengerController {
	@Autowired
	private PassengerService passengerService;
	
	@PostMapping
	public ResponseEntity<Passenger> addPassenger(Passenger passenger){
		return new ResponseEntity<Passenger> (passengerService.addPassenger(passenger),HttpStatus.CREATED);
	}
	@GetMapping
	public List<Passenger> getAllPassenger(){
		return passengerService.getAllPassenger();
	}
	@GetMapping("/{pId}")
	public ResponseEntity<Passenger> getPassengerById(@PathVariable("pId") int pId) {
		return new ResponseEntity<Passenger> (passengerService.getPassengerById(pId),HttpStatus.OK);
	}
	@DeleteMapping("/{pId}")
	public ResponseEntity<String> removePassengerById(@PathVariable("pId") int pId){
		passengerService.getPassengerById(pId);
		return new ResponseEntity<String> (" Passenger Deleted SuccessFully",HttpStatus.OK);
	}
	
}
